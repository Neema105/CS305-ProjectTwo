package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@SpringBootApplication
public class SslServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    @GetMapping("/checksum")
    public String checksum() {
        try {
            // Wrapped the code in a try block to safely handle exceptions
            String data = "Neema Taghipour's Checksum Verification!";
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder(digest.length * 2);
            for (byte b : digest) hex.append(String.format("%02x", b));
            return data + "\n" + hex.toString() + "\n";
        } catch (Exception e) {
            // Added a catch block to prevent the application from exposing internal errors
            // This replaces 'throws Exception' and improves security and reliability
            return "Error generating checksum.";
        }
    }
    
}
